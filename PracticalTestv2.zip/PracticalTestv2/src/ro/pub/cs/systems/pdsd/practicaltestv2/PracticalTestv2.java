package ro.pub.cs.systems.pdsd.practicaltestv2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

class Utilities {

	public static BufferedReader getReader(Socket socket) throws IOException {
		return new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	
	public static PrintWriter getWriter(Socket socket) throws IOException {
		return new PrintWriter(socket.getOutputStream(), true);
	}

}

public class PracticalTestv2 extends Activity {

	EditText portEdit, cityEdit, optionEdit;
	Button startButton, sendButton;
	TextView infoText;
	ServerThread serverThread;
	int port;
	
	class Meteo {
		String condition;
		String temperature;
		String wind;
		Element table;
		String pressure;
		String humidity;
	}
	
	class StartServerButtonListener implements Button.OnClickListener {

		@Override
		public void onClick(View v) {
			Log.d("CLICK", "STARTING SERVER");
			port = Integer.parseInt(portEdit.getText().toString());
			
			serverThread = new ServerThread();
			serverThread.startServer(port);
		}
		
	}
	
	class SendButtonListener implements Button.OnClickListener {

		@Override
		public void onClick(View v) {
			infoText.setText("");
			int port = Integer.parseInt(portEdit.getText().toString());
			
			ClientThread clientThread = new ClientThread();
			clientThread.start();
		}
		
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical_testv2);
        portEdit = (EditText) this.findViewById(R.id.port);
        cityEdit = (EditText) this.findViewById(R.id.city);
        optionEdit = (EditText) this.findViewById(R.id.option);
        startButton = (Button) this.findViewById(R.id.start);
        sendButton = (Button) this.findViewById(R.id.send);
        infoText = (TextView) this.findViewById(R.id.info);
        
        startButton.setOnClickListener(new StartServerButtonListener());
        sendButton.setOnClickListener(new SendButtonListener());
    }

    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.practical_testv2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected void onDestroy() {
      if (serverThread != null) {
        serverThread.stopServer();
      }
      super.onDestroy();
    }
    
    private class ClientThread extends Thread {
		
		private Socket socket = null;
		
		@Override
		public void run() {
			try {				
				String city = cityEdit.getText().toString();
				String option = optionEdit.getText().toString();
				Socket socket = new Socket("127.0.0.1", port);
				
				PrintWriter writer = Utilities.getWriter(socket);
				writer.println(city);
				writer.flush();
				writer.println(option);
				writer.flush();
				
				BufferedReader reader = Utilities.getReader(socket);
				
				while(true) {
					final String line = reader.readLine();
					if (line.equals("end"))
						break;
					
					infoText.post(new Runnable() {

						@Override
						public void run() {
							String text = infoText.getText().toString();
							infoText.setText(text + "\n" + line);
						}
						
					});
				}
				
				socket.close();
			} catch (Exception exception) {
					exception.printStackTrace();
			}			
		}
	}	
    
    private class ServerThread extends Thread {
		
		private boolean isRunning;
		int port;
		private ServerSocket serverSocket;
		private HashMap<String, Meteo> cache;
		
		public void startServer(int port) {
			this.port = port;
			isRunning = true;
			cache = new HashMap<String, Meteo>();
			start();
		}
		
		public void stopServer() {
			isRunning = false;
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						if (serverSocket != null) {
							serverSocket.close();
						}
					} catch(IOException ioException) {
							ioException.printStackTrace();
						}
				}
			}).start();
		}
		
		@Override
		public void run() {
			try {
				
				serverSocket = new ServerSocket(port);
				Log.d("SERVER", "Server is running");
				
				while (isRunning) {
					Socket socket = serverSocket.accept();
					
					BufferedReader reader = Utilities.getReader(socket);
					
					String city = reader.readLine();
					String option = reader.readLine();
					
					Log.d("OPTION", option);
					
					Meteo meteo = null;
					if (cache.containsKey(city))
						meteo = cache.get(city);
					else {
						meteo = new Meteo();
						HttpClient httpClient = new DefaultHttpClient();
					
						String url = "http://www.wunderground.com/cgi-bin/findweather/getForecast?query=" + city;
					
						HttpGet httpGet = new HttpGet(url);
						ResponseHandler handler = new BasicResponseHandler();
					
						String content = httpClient.execute(httpGet, handler);
					}
					PrintWriter writer = Utilities.getWriter(socket);
					if (option.compareTo("all") == 0) {
						writer.println(meteo.condition);
						writer.println(meteo.temperature);
						writer.println(meteo.wind);
						writer.println(meteo.pressure);
						writer.println(meteo.humidity);
					}
					if (option.compareTo("condition") == 0) {
						writer.println(meteo.condition);
					}
					if (option.compareTo("temperature") == 0) {
						writer.println(meteo.temperature);
					}
					if (option.compareTo("wind") == 0) {
						writer.println(meteo.wind);
					}
					if (option.compareTo("pressure") == 0) {
						writer.println(meteo.pressure);
					}
					if (option.compareTo("humidity") == 0) {
						writer.println(meteo.humidity);
					}
					writer.println("end");
					
					socket.close();
				}
			} catch (IOException ioException) {
					ioException.printStackTrace();
			}
		}
	}
}
